@class SPTSpec;

typedef void (^SPTVoidBlock)();
typedef void (^SPTSpecBlock)(SPTSpec *spec);
typedef void (^SPTDictionaryBlock)(NSDictionary *dictionary);
