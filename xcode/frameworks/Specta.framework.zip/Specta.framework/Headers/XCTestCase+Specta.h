#import <XCTest/XCTest.h>

@interface XCTestCase (Specta)

- (void)spt_handleException:(NSException *)exception;

@end
