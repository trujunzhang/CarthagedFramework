#import "Expecta.h"

EXPMatcherInterface(beInstanceOf,   (Class expected));
EXPMatcherInterface(beAnInstanceOf, (Class expected));
EXPMatcherInterface(beMemberOf,     (Class expected));
EXPMatcherInterface(beAMemberOf,    (Class expected));
