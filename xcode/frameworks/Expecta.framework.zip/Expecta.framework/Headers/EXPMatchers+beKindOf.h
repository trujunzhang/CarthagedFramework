#import "Expecta.h"

EXPMatcherInterface(beKindOf,  (Class expected));
EXPMatcherInterface(beAKindOf, (Class expected));
