#import "Expecta.h"

EXPMatcherInterface(match, (NSString *expected));
