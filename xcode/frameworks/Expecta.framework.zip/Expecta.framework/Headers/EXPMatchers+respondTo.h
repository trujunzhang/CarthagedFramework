#import "Expecta.h"

EXPMatcherInterface(respondTo, (SEL expected));
