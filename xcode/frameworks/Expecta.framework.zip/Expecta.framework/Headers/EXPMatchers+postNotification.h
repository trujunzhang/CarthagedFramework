#import "Expecta.h"

EXPMatcherInterface(postNotification, (id expectedNotification));
EXPMatcherInterface(notify, (id expectedNotification));
