#import "Expecta.h"

EXPMatcherInterface(beSupersetOf, (id subset));

