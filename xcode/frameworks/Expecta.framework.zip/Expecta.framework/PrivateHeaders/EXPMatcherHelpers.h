#import <Foundation/Foundation.h>

BOOL EXPIsValuePointer(NSValue *value);
BOOL EXPIsNumberFloat(NSNumber *number);
