#import <Foundation/Foundation.h>

@interface NSValue (Expecta)

@property (nonatomic) const char *_EXP_objCType;

@end
